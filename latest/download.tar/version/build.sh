#!/bin/sh
grunt -v --force >> build.log